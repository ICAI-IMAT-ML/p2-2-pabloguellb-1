black .
mypy --cache-dir=/dev/null --check-untyped-defs --ignore-missing-imports .