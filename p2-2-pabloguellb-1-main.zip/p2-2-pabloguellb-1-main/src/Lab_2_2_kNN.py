# Laboratory practice 2.2: KNN classification
import seaborn as sns
import matplotlib.pyplot as plt
sns.set_theme()
import numpy as np  
import seaborn as sns


def minkowski_distance(a, b, p=2):
    """
    Compute the Minkowski distance between two arrays.

    Args:
        a (np.ndarray): First array.
        b (np.ndarray): Second array.
        p (int, optional): The degree of the Minkowski distance. Defaults to 2 (Euclidean distance).

    Returns:
        float: Minkowski distance between arrays a and b.
    """

    # TODO
    distance = 0

    if len(a) == len(b):
        for i in range(len(a)):
            distance += (b[i] - a[i])**p

    return distance ** (1/p)

# k-Nearest Neighbors Model

# - [K-Nearest Neighbours](https://scikit-learn.org/stable/modules/neighbors.html#classification)
# - [KNeighborsClassifier](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html)


import numpy as np
from collections import Counter

class knn:
    def __init__(self):
        """Initialize KNN model with default values."""
        self.k = None
        self.p = None
        self.x_train = None
        self.y_train = None

    def minkowski_distance(self, a, b, p=2):
        """Compute the Minkowski distance between two arrays."""
        return np.sum(np.abs(a - b) ** p) ** (1 / p)

    def fit(self, X_train: np.ndarray, y_train: np.ndarray, k: int = 5, p: int = 2):
        """
        Fit the model using X as training data and y as target values.

        Args:
            X_train (np.ndarray): Training data.
            y_train (np.ndarray): Target values.
            k (int, optional): Number of neighbors to use. Defaults to 5.
            p (int, optional): The degree of the Minkowski distance. Defaults to 2.

        Raises:
            ValueError: If inputs are invalid.
        """
        if X_train.shape[0] != y_train.shape[0]:
            raise ValueError("X_train and y_train must have the same number of rows.")
        if not isinstance(k, int) or k <= 0:
            raise ValueError("k must be a positive integer.")
        if not isinstance(p, int) or p <= 0:
            raise ValueError("p must be a positive integer.")

        self.k = k
        self.p = p
        self.x_train = X_train
        self.y_train = y_train

    def compute_distances(self, X):
        """Compute distance from each test sample to all training samples."""
        return np.array([
            [self.minkowski_distance(x_test, x_train, self.p) for x_train in self.x_train]
            for x_test in X
        ])

    def get_k_nearest_neighbors(self, distances):
        """Get indices of k nearest neighbors for each test sample."""
        return np.argsort(distances, axis=1)[:, :self.k]

    def most_common_label(self, knn_labels):
        """Get the most common label among k nearest neighbors."""
        return np.array([Counter(labels).most_common(1)[0][0] for labels in knn_labels])

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict the class labels for the provided data.

        Args:
            X (np.ndarray): Data samples to predict their labels.

        Returns:
            np.ndarray: Predicted class labels.
        """
        if self.x_train is None or self.y_train is None:
            raise ValueError("Model is not trained. Call fit() before predicting.")

        distances = self.compute_distances(X)
        knn_indices = self.get_k_nearest_neighbors(distances)
        knn_labels = self.y_train[knn_indices]
        predictions = self.most_common_label(knn_labels)

        return predictions

    def predict_proba(self, X):
        """
        Predict the class probabilities for the provided data.

        Each class probability is the amount of each label from the k nearest neighbors
        divided by k.

        Args:
            X (np.ndarray): data samples to predict their labels.

        Returns:
            np.ndarray: Predicted class probabilities.
        """
        if self.x_train is None or self.y_train is None:
            raise ValueError("Model is not trained. Call fit() before predicting.")

        distances = self.compute_distances(X)
        knn_indices = self.get_k_nearest_neighbors(distances)
        knn_labels = self.y_train[knn_indices]

        probabilities = []
        for labels in knn_labels:
            label_counts = Counter(labels)
            total_neighbors = len(labels)
            prob = {label: count / total_neighbors for label, count in label_counts.items()}
            probabilities.append([prob.get(0, 0), prob.get(1, 0)])

        return np.array(probabilities)

    def __str__(self):
        """String representation of the kNN model."""
        return f"kNN model (k={self.k}, p={self.p})"




def plot_2Dmodel_predictions(X, y, model, grid_points_n):
    """
    Plot the classification results and predicted probabilities of a model on a 2D grid.

    This function creates two plots:
    1. A classification results plot showing True Positives, False Positives, False Negatives, and True Negatives.
    2. A predicted probabilities plot showing the probability predictions with level curves for each 0.1 increment.

    Args:
        X (np.ndarray): The input data, a 2D array of shape (n_samples, 2), where each row represents a sample and each column represents a feature.
        y (np.ndarray): The true labels, a 1D array of length n_samples.
        model (classifier): A trained classification model with 'predict' and 'predict_proba' methods. The model should be compatible with the input data 'X'.
        grid_points_n (int): The number of points in the grid along each axis. This determines the resolution of the plots.

    Returns:
        None: This function does not return any value. It displays two plots.

    Note:
        - This function assumes binary classification and that the model's 'predict_proba' method returns probabilities for the positive class in the second column.
    """
    # Map string labels to numeric
    unique_labels = np.unique(y)
    num_to_label = {i: label for i, label in enumerate(unique_labels)}

    # Predict on input data
    preds = model.predict(X)

    # Determine TP, FP, FN, TN
    tp = (y == unique_labels[1]) & (preds == unique_labels[1])
    fp = (y == unique_labels[0]) & (preds == unique_labels[1])
    fn = (y == unique_labels[1]) & (preds == unique_labels[0])
    tn = (y == unique_labels[0]) & (preds == unique_labels[0])

    # Plotting
    fig, ax = plt.subplots(1, 2, figsize=(12, 5))

    # Classification Results Plot
    ax[0].scatter(X[tp, 0], X[tp, 1], color="green", label=f"True {num_to_label[1]}")
    ax[0].scatter(X[fp, 0], X[fp, 1], color="red", label=f"False {num_to_label[1]}")
    ax[0].scatter(X[fn, 0], X[fn, 1], color="blue", label=f"False {num_to_label[0]}")
    ax[0].scatter(X[tn, 0], X[tn, 1], color="orange", label=f"True {num_to_label[0]}")
    ax[0].set_title("Classification Results")
    ax[0].legend()

    # Create a mesh grid
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(
        np.linspace(x_min, x_max, grid_points_n),
        np.linspace(y_min, y_max, grid_points_n),
    )

    # # Predict on mesh grid
    grid = np.c_[xx.ravel(), yy.ravel()]
    probs = model.predict_proba(grid)[:, 1].reshape(xx.shape)

    # Use Seaborn for the scatter plot
    sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=y, palette="Set1", ax=ax[1])
    ax[1].set_title("Classes and Estimated Probability Contour Lines")

    # Plot contour lines for probabilities
    cnt = ax[1].contour(xx, yy, probs, levels=np.arange(0, 1.1, 0.1), colors="black")
    ax[1].clabel(cnt, inline=True, fontsize=8)

    # Show the plot
    plt.tight_layout()
    plt.show()



def evaluate_classification_metrics(y_true, y_pred, positive_label):
    """
    Calculate various evaluation metrics for a classification model.

    Args:
        y_true (array-like): True labels of the data.
        y_pred (array-like): Predicted labels by the model.
        positive_label: The label considered as the positive class.

    Returns:
        dict: A dictionary containing various evaluation metrics.

    Metrics Calculated:
        - Confusion Matrix: [TN, FP, FN, TP]
        - Accuracy: (TP + TN) / (TP + TN + FP + FN)
        - Precision: TP / (TP + FP)
        - Recall (Sensitivity): TP / (TP + FN)
        - Specificity: TN / (TN + FP)
        - F1 Score: 2 * (Precision * Recall) / (Precision + Recall)
    """
    # Convert labels to binary (0 and 1)
    y_true_mapped = np.array([1 if label == positive_label else 0 for label in y_true])
    y_pred_mapped = np.array([1 if label == positive_label else 0 for label in y_pred])

    # Compute confusion matrix components
    TP = np.sum((y_true_mapped == 1) & (y_pred_mapped == 1))  # True Positives
    TN = np.sum((y_true_mapped == 0) & (y_pred_mapped == 0))  # True Negatives
    FP = np.sum((y_true_mapped == 0) & (y_pred_mapped == 1))  # False Positives
    FN = np.sum((y_true_mapped == 1) & (y_pred_mapped == 0))  # False Negatives

    # Calculate metrics
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    precision = TP / (TP + FP) if (TP + FP) > 0 else 0
    recall = TP / (TP + FN) if (TP + FN) > 0 else 0
    specificity = TN / (TN + FP) if (TN + FP) > 0 else 0
    f1_score = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

    return {
        "Confusion Matrix": [TN, FP, FN, TP],
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "Specificity": specificity,
        "F1 Score": f1_score,
    }




def plot_calibration_curve(y_true, y_probs, positive_label, n_bins=10):
    """
    Plot a calibration curve to evaluate the accuracy of predicted probabilities.

    This function creates a plot that compares the mean predicted probabilities
    in each bin with the fraction of positives (true outcomes) in that bin.
    This helps assess how well the probabilities are calibrated.

    Args:
        y_true (array-like): True labels of the data. Can be binary or categorical.
        y_probs (array-like): Predicted probabilities for the positive class (positive_label).
                              Expected values are in the range [0, 1].
        positive_label (int or str): The label that is considered the positive class.
                                     Used to map categorical labels to binary outcomes.
        n_bins (int, optional): Number of bins to use for grouping predicted probabilities.
                                Defaults to 10. Bins are equally spaced in the range [0, 1].

    Returns:
        dict: A dictionary with the following keys:
            - "bin_centers": Array of the center values of each bin.
            - "true_proportions": Array of the fraction of positives in each bin
    """
    # 1) Mapear y_true a 0/1 según la clase positiva
    y_true_mapped = np.array([1 if label == positive_label else 0 for label in y_true])

    # 2) Crear los bordes de los bins (intervalos)
    bin_edges = np.linspace(0, 1, n_bins + 1)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

    # 3) Para cada bin, calcular la fracción de positivos reales y la media de predicciones
    true_proportions = []
    mean_predictions = []

    for i in range(n_bins):
        start, end = bin_edges[i], bin_edges[i + 1]
        mask = (y_probs >= start) & (y_probs < end)

        # Manejar el caso de bins vacíos
        if np.sum(mask) == 0:
            true_proportions.append(np.nan)
            mean_predictions.append((start + end) / 2)
            continue

        # Fracción de positivos en este bin
        fraction_positives = np.mean(y_true_mapped[mask])
        true_proportions.append(fraction_positives)

        # Media de la probabilidad predicha en este bin
        avg_pred_prob = np.mean(y_probs[mask])
        mean_predictions.append(avg_pred_prob)

    # 4) Graficar la curva de calibración
    plt.figure(figsize=(6, 6))
    plt.plot(mean_predictions, true_proportions, "o-", label="Calibration Curve")
    plt.plot([0, 1], [0, 1], "k--", label="Perfect Calibration")
    plt.title("Calibration Curve")
    plt.xlabel("Mean Predicted Probability")
    plt.ylabel("Fraction of Positives")
    plt.legend()
    plt.grid(True)
    plt.show()

    return {
        "bin_centers": bin_centers,
        "true_proportions": np.array(true_proportions)
    }



import numpy as np
import matplotlib.pyplot as plt

def plot_probability_histograms(y_true, y_probs, positive_label, n_bins=10):
    """
    Plot probability histograms for the positive and negative classes separately.

    This function creates two histograms showing the distribution of predicted
    probabilities for each class. This helps in understanding how the model
    differentiates between the classes.

    Args:
        y_true (array-like): True labels of the data. Can be binary or categorical.
        y_probs (array-like): Predicted probabilities for the positive class. 
                              Expected values are in the range [0, 1].
        positive_label (int or str): The label considered as the positive class.
                                     Used to map categorical labels to binary outcomes.
        n_bins (int, optional): Number of bins for the histograms. Defaults to 10. 
                                Bins are equally spaced in the range [0, 1].

    Returns:
        dict: A dictionary with the following keys:
            - "array_passed_to_histogram_of_positive_class": 
                Array of predicted probabilities for the positive class.
            - "array_passed_to_histogram_of_negative_class": 
                Array of predicted probabilities for the negative class.
    """
    # Convert true labels to 0/1
    y_true_mapped = np.array([1 if label == positive_label else 0 for label in y_true])

    # Separate probabilities based on the true class
    pos_probs = y_probs[y_true_mapped == 1]
    neg_probs = y_probs[y_true_mapped == 0]

    # Plot histograms
    plt.figure(figsize=(10, 5))

    # Histogram for the positive class
    plt.subplot(1, 2, 1)
    plt.hist(pos_probs, bins=n_bins, range=(0, 1), color='blue', edgecolor='black')
    plt.title("Histogram of Predicted Probabilities (Positive Class)")
    plt.xlabel("Predicted Probability")
    plt.ylabel("Frequency")

    # Histogram for the negative class
    plt.subplot(1, 2, 2)
    plt.hist(neg_probs, bins=n_bins, range=(0, 1), color='red', edgecolor='black')
    plt.title("Histogram of Predicted Probabilities (Negative Class)")
    plt.xlabel("Predicted Probability")
    plt.ylabel("Frequency")

    plt.tight_layout()
    plt.show()

    return {
        "array_passed_to_histogram_of_positive_class": pos_probs,
        "array_passed_to_histogram_of_negative_class": neg_probs,
    }


import numpy as np
import matplotlib.pyplot as plt

def plot_roc_curve(y_true, y_probs, positive_label):
    """
    Plot the Receiver Operating Characteristic (ROC) curve.

    The ROC curve is a graphical representation of the diagnostic ability of a binary
    classifier system as its discrimination threshold is varied. It plots the True Positive
    Rate (TPR) against the False Positive Rate (FPR) at various threshold settings.

    Args:
        y_true (array-like): True labels of the data. Can be binary or categorical.
        y_probs (array-like): Predicted probabilities for the positive class. 
                              Expected values are in the range [0, 1].
        positive_label (int or str): The label considered as the positive class.
                                     Used to map categorical labels to binary outcomes.

    Returns:
        dict: A dictionary containing the following:
            - "fpr": Array of False Positive Rates for each threshold.
            - "tpr": Array of True Positive Rates for each threshold.
    """
    # Convert true labels to 0 or 1 based on the positive label
    y_true_mapped = np.array([1 if label == positive_label else 0 for label in y_true])

    # Get unique thresholds from the predicted probabilities, sorted in ascending order
    thresholds = np.sort(np.unique(y_probs))

    tprs = []
    fprs = []

    for thresh in thresholds:
        # Predict class 1 if probability >= threshold
        y_pred_mapped = (y_probs >= thresh).astype(int)

        # Compute confusion matrix components
        TP = np.sum((y_true_mapped == 1) & (y_pred_mapped == 1))
        TN = np.sum((y_true_mapped == 0) & (y_pred_mapped == 0))
        FP = np.sum((y_true_mapped == 0) & (y_pred_mapped == 1))
        FN = np.sum((y_true_mapped == 1) & (y_pred_mapped == 0))

        # Calculate TPR and FPR
        TPR = TP / (TP + FN) if (TP + FN) != 0 else 0
        FPR = FP / (FP + TN) if (FP + TN) != 0 else 0

        tprs.append(TPR)
        fprs.append(FPR)

    # Sort the pairs (FPR, TPR) by FPR so the curve is drawn correctly
    sorted_pairs = sorted(zip(fprs, tprs))
    sorted_fprs, sorted_tprs = zip(*sorted_pairs)

    # Plot the ROC curve
    plt.figure(figsize=(6, 6))
    plt.plot(sorted_fprs, sorted_tprs, label="ROC Curve", marker="o")
    plt.plot([0, 1], [0, 1], "k--", label="Random Guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend()
    plt.grid(True)
    plt.show()

    return {"fpr": np.array(sorted_fprs), "tpr": np.array(sorted_tprs)}

